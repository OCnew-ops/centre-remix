import json,base64,sys,websocket,urllib.request,time
tabs=json.load(urllib.request.urlopen("http://127.0.0.1:9224/json"))
t=[x for x in tabs if x['url'].startswith('http://127.0.0.1:8765')][0]
ws=websocket.create_connection(t['webSocketDebuggerUrl'],timeout=60,max_size=200_000_000,suppress_origin=True)
i=[0]
def cmd(m,p=None):
    i[0]+=1
    ws.send(json.dumps({"id":i[0],"method":m,"params":p or {}}))
    while True:
        r=json.loads(ws.recv())
        if r.get('id')==i[0]:
            if 'error' in r: raise SystemExit(r['error'])
            return r['result']
W=int(sys.argv[2]); H=int(sys.argv[3])
cmd("Emulation.setDeviceMetricsOverride",{"width":W,"height":H,"deviceScaleFactor":1,"mobile":False})
time.sleep(2)
r=cmd("Page.captureScreenshot",{"format":"png","captureBeyondViewport":True})
open(sys.argv[1],'wb').write(base64.b64decode(r['data']))
cmd("Emulation.clearDeviceMetricsOverride")
print("saved",sys.argv[1])
