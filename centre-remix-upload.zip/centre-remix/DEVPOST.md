# Devpost paste (Centre Remix)

Deadline: 3 Sep 2026 1:00pm PT (4 Sep 2026 6:00am Australia/Sydney)

## Submission checklist
- [ ] Join the hackathon on https://webmcp.devpost.com/
- [ ] Live URL (host the static folder; Netlify Drop / Surge / GitHub Pages / Cloudflare / Vercel all fine)
- [ ] Public GitHub repo with LICENSE visible (MIT already in folder)
- [ ] YouTube demo under 3 minutes (file ready under demo/ when built)
- [ ] Paste the text below into the Devpost description

## Project name
Centre Remix

## Tagline
A shopping-centre leasing board where the human and the agent share the same live floor plan via WebMCP.

## Elevator pitch / description (paste)

Centre Remix is a single-page leasing board for Harbour Place, a fictional shopping centre in Millers Reach, NSW. Australian centres already run near full occupancy, so the real job is remix (who should replace whom), not filling empty shops.

WebMCP is the fit because the agent should act on the same board the leasing manager is staring at, not a chatbot bolted onto a brochure. The page registers ten tools with document.modelContext.registerTool. Each tool mutates or queries the live UI in this tab. There is no backend, no API key, and no login. If the human rejects a proposal, it never hits the sitting tenant.

Humans click tiles, filters, and Accept / Reject on remix overlays. Agents call list_tenants, get_shop, focus_shop, propose_remix, apply_remix, reject_remix, draft_outreach, set_expiry_window, summarise_mix, and undo_last. A Simulate agent panel in the sidebar calls the same JavaScript functions, so judges can demo without ChatGPT.

All figures are SAMPLE DATA. Tenants, rents, expiries, and productivity bands are invented. They do not describe a real asset.

Built with vanilla HTML, CSS, and JavaScript. Open index.html or serve the folder. Works in ChatGPT desktop in-app browser, or Chrome 149+ with chrome://flags/#enable-webmcp-testing.

## Built with
HTML, CSS, JavaScript, WebMCP (document.modelContext.registerTool)

## Links to fill on the form
- Live URL: (after GitHub Pages or Netlify Drop. Temporary Vercel URLs expired 3 Sep 2026. Do not claim old Vercel.)
- Repo URL: (paste after GitHub push)
- YouTube URL: (paste after you publish demo/centre-remix-demo.mp4)

## Your taps only
1. Public GitHub repo, push this folder (device login on Grok's computer if asked)
2. Host the static folder with Netlify Drop or GitHub Pages (do not claim old Vercel)
3. Upload demo/centre-remix-demo.mp4 to YouTube as public, under 3 minutes
4. Join https://webmcp.devpost.com/ and submit with live + repo + YouTube and the description above

## Status as of 3 Sep 2026 10:10am Sydney

Ready without Joseph:
- App, README, MIT LICENSE, local git on main
- Demo video with audio (~83s): demo/centre-remix-demo.mp4
- YouTube paste: demo/YOUTUBE.md
- Devpost description paste: sections above

Hosting:
- Temporary Vercel URLs are dead (deployment expired). Do not claim them.
- Next host: Netlify Drop or GitHub Pages after the public repo push.

Still needs Joseph (deadline 3 Sep 1:00pm PT / 4 Sep 6:00am Sydney):
1. Public GitHub repo push (device login on Grok computer if asked)
2. Netlify Drop or GitHub Pages
3. YouTube publish of demo/centre-remix-demo.mp4 (paste from demo/YOUTUBE.md)
4. Join https://webmcp.devpost.com/ and submit with live + repo + YouTube URLs
